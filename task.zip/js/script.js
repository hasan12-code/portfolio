document.addEventListener("DOMContentLoaded", function () {
    const menuButton = document.querySelector(".menu_btn button");
    const mobileMenu = document.getElementById("mobile-menu");
    const overlay = document.querySelector(".overlay");


    menuButton.addEventListener("click", function (e) {
        e.preventDefault();
        mobileMenu.classList.toggle('active');
        overlay.classList.toggle('active');
    });
    window.close_menu = function () {
        mobileMenu.classList.remove('active');
        overlay.classList.remove('active');
    }


    overlay.addEventListener("click", close_menu);


    function createErrorMessage(container, arg) {

        const error_html = `<div class="error-note">
                                <p>${arg}</p>
                            </div>`;

        container.insertAdjacentHTML('beforeend', error_html);

        setTimeout(() => {
            var errors = container.querySelector(".error-note");
            errors.classList.add("fade-out");
            errors.addEventListener("transitionend", function () {
                this.remove();
            });
        }, 1500);
    }

    const contact_form = document.getElementById("contact-form");


    const name_regxp = /^[a-zA-Z\s]+$/;
    const email_regxp = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phone_regxp = /^[6-9]\d{9}$/;

    contact_form.addEventListener("submit", function (e) {

        e.preventDefault();

        const errorNotes = this.querySelectorAll(".error-note");
        if (errorNotes) {
            errorNotes.forEach(note => note.remove());
        }
        const first_name = document.getElementById("first_name").value.trim();
        const last_name = document.getElementById("last_name").value.trim();
        const email = document.getElementById("email").value.trim().toLowerCase();




        const phone = document.getElementById("phone").value.trim();
        const message = document.getElementById("message").value.trim();

        if ((first_name == null || first_name == "") || (last_name == null || last_name == "") || (email == null || email == "") || (phone == null || phone == "") || (message == null || message == "")) {
            createErrorMessage(this, "All  fields are required");;
            return;
        }
        if (!name_regxp.test(first_name) || !name_regxp.test(last_name)) {
            createErrorMessage(this, "Please enter a valid name");
            return;
        }
        if (!email_regxp.test(email)) {
            createErrorMessage(this, "Please enter a valid email");
            return;
        }
        if (!phone_regxp.test(phone)) {
            createErrorMessage(this, "Please enter a valid phone number");
            return;
        }
        if (message.length < 10) {
            createErrorMessage(this, "Please enter a valid message");
            return;
        }
        this.reset();
        document.querySelector(".form-btn button").setAttribute("disabled", "true");
        document.querySelector(".form-btn button").innerHTML = `<i class="fa fa-check" aria-hidden="true" style="margin-right:4px"></i>Form Submitted Successfully By ${first_name}  ${last_name}`;
    });
});